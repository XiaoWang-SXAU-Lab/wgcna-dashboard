# Arabidopsis heat-stress memory demo dataset

Source: **"Heteromeric HSFA2/HSFA3 complexes drive transcriptional memory after heat stress in Arabidopsis"** — Nature Communications, 2021. PMID 34103516, GEO GSE162434.

## Design

48 bulk RNA-seq samples of Arabidopsis thaliana (Col-0 background):

- 3 biological replicates
- 4 genotypes: `Col` (WT), `hsfa2`, `hsfa3`, `hsfa2_3` (double mutant)
- 4 conditions: `NTC` (no heat), `ACC+4h`, `ACC+28h`, `ACC+52h` (heat-priming / memory time points)

## Files

- `expr.tsv` — raw read counts, gene x sample (33,323 genes x 48 samples)
- `trait.tsv` — one-hot trait matrix by `group` (genotype): Col / hsfa2 / hsfa3 / hsfa2_3
- `sample_info.tsv` — sample metadata (genotype / condition / replicate / species)
- `build_demo.py` — regenerates the three TSVs from `GSE162434_RAW.tar`

## How to load in the dashboard

1. Data import: upload `expr.tsv` as the expression matrix and `trait.tsv` as the trait table.
2. Normalization: choose `vst (DESeq2) — Raw count` (recommended) or `log2(x+1) — Raw count`.
3. Module-trait step: correlate modules against the genotype categories (one-hot group matrix).
